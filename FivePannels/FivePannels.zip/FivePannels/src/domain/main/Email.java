package main;

public class Email
{
    private final String eMail;

    public Email(String eMail)
    {
        this.eMail = eMail;
    }

    public String geteMail()
    {
        return eMail;
    }
}
